from donusumler.frmGirisUİ import Ui_frmGiris
from donusumler.frmDurumUİ import Ui_frmDurum
from PyQt5.QtWidgets import QMessageBox
from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt
import datetime
import requests
import sys


class frmGiris(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmGiris, self).__init__()
        self.ui = Ui_frmGiris()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.FramelessWindowHint)

        # Ara butonuna tıklama olayını bağla
        self.ui.btnAra.clicked.connect(self.hava_durumunu_al)
        self.ui.btnAra_2.clicked.connect(self.cikis)

        # frmDurum penceresini oluştur
        self.durumPenceresi = frmDurum()
        self.durumPenceresi.ui.btnGeri.clicked.connect(self.geriDon)

    def hava_durumunu_al(self):
        sehir = self.ui.lblSehir.text()
        api_anahtari = 'API EKLE'  # OpenWeatherMap API anahtarınızı buraya ekleyin

        # Geocoding API URL
        coğrafi_konum_url = f'http://api.openweathermap.org/geo/1.0/direct?q={sehir}&limit=1&appid={api_anahtari}'

        try:
            coğrafi_konum_cevabi = requests.get(coğrafi_konum_url)
            coğrafi_konum_verisi = coğrafi_konum_cevabi.json()

            if len(coğrafi_konum_verisi) == 0:
                QMessageBox.warning(self, 'Hata', 'Şehir bulunamadı.')
                return

            enlem = coğrafi_konum_verisi[0]['lat']
            boylam = coğrafi_konum_verisi[0]['lon']

            # Weather API URL
            hava_durumu_url = f'https://api.openweathermap.org/data/2.5/weather?lat={enlem}&lon={boylam}&appid={api_anahtari}&units=metric&lang=tr'
            hava_durumu_cevabi = requests.get(hava_durumu_url)
            hava_durumu_verisi = hava_durumu_cevabi.json()

            if hava_durumu_verisi['cod'] == 200:
                sicaklik = hava_durumu_verisi['main']['temp']
                hava_aciklamasi = hava_durumu_verisi['weather'][0]['description']
                durum_aciklama = '\n'.join(hava_aciklamasi.split(' '))
                saat = datetime.datetime.now().strftime('%H:%M')

                # frmDurum penceresindeki etiketlere verileri ata
                self.durumPenceresi.ui.lblDurum.setText(durum_aciklama)
                self.durumPenceresi.ui.lblSaat.setText(saat)
                self.durumPenceresi.ui.lblSehir.setText(sehir)
                self.durumPenceresi.ui.lblSicaklik.setText(f'{int(sicaklik)}')
                self.durumPenceresi.ui.lblSicaklik_2.setText(f'{int(sicaklik)}')

                # frmDurum penceresini göster
                self.durumPenceresi.show()
                self.close()  # frmGiris'i kapat
            else:
                hata_mesaji = hava_durumu_verisi.get("message", "Bilinmeyen hata")
                QMessageBox.warning(self, 'Hata', f'Hava durumu alınamadı: {hata_mesaji}')
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, 'Hata', f'API isteğinde bir hata oluştu: {e}')
        except Exception as e:
            QMessageBox.critical(self, 'Hata', f'Bir hata oluştu: {e}')

    def geriDon(self):
        self.durumPenceresi.close()
        self.show()

    def cikis(self):
        QtWidgets.QApplication.quit()

class frmDurum(QtWidgets.QMainWindow):
    def __init__(self):
        super(frmDurum, self).__init__()
        self.ui = Ui_frmDurum()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.FramelessWindowHint)


# Uygulama Başlatma Fonksiyonu Oluşturma:
def baslat():
    uygulama = QtWidgets.QApplication(sys.argv)
    pencere = frmGiris()
    pencere.show()
    sys.exit(uygulama.exec_())

# Uygulamayı Başlat:
if __name__ == "__main__":
    baslat()
