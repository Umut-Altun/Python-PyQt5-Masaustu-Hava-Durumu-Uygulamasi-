import subprocess

# pyrcc5 -o resimler/resimler_rc.py resimler/resimler.qrc
# pyinstaller --onefile --icon=loggo.ico --noconsole app.py

# Dönüştürülecek UI dosyalarını listeye ekleyin.
tasarimlar = [
    "tasarimlar/frmGiris.ui",
    "tasarimlar/frmDurum.ui",
    # Diğer UI dosyalarını buraya ekleyebilirsiniz...
]

# Her UI dosyasını py dosyasına dönüştürün.
for tasarim in tasarimlar:
    # Ui dosyasını, Py dosyası adına çevirin
    py_dosya = f"donusumler/{tasarim.split("/")[-1].replace(".ui", "Uİ")}.py"

    # pyuic5 komutunu oluşturun.
    komut = ["pyuic5",tasarim,"-o",py_dosya]

    try:
        # subprocess modülü ile komutu çalıştırın.
        subprocess.run(komut,check=True)
        print(f"{tasarim} donüştürüldü")
    except subprocess.CalledProcessError:
        print(f"{tasarim} hata...")
        

